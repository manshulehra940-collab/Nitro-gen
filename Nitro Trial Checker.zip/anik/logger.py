import os
import sys
import time
import threading
from datetime import datetime

try:
    import colorama
    colorama.init(autoreset=True)
except ImportError:
    pass


class Colors:
    RESET = "\033[0m"
    GREEN = "\033[38;5;46m"
    YELLOW = "\033[38;5;226m"
    RED = "\033[38;5;196m"
    CYAN = "\033[38;5;51m"
    MAGENTA = "\033[38;5;205m"
    PINK = "\033[38;5;205m"
    ORANGE = "\033[38;5;208m"
    LIGHT_BLUE = "\033[38;5;39m"
    VIOLET = "\033[38;5;129m"
    WHITE = "\033[38;5;231m"
    GRAY = "\033[38;5;244m"
    BOLD = "\033[1m"
    DIM = "\033[2m"


class Logger:
    """
    Console logger with fixed-width column alignment, connected grid lines,
    thread safety, and rich 256-color palette.
    """

    def __init__(self) -> None:
        self.BLUE = "\033[38;5;27m"
        self.GRAY = "\033[38;5;244m"
        self.DARK_BLUE = "\033[38;5;19m"
        self.GREEN = "\033[38;5;46m"
        self.YELLOW = "\033[38;5;226m"
        self.CYAN = "\033[38;5;51m"
        self.WHITE = "\033[38;5;231m"
        self.RED = "\033[38;5;196m"
        self.PINK = "\033[38;5;205m"
        self.ORANGE = "\033[38;5;208m"
        self.LIGHT_BLUE = "\033[38;5;39m"
        self.VIOLET = "\033[38;5;129m"
        self.RESET = "\033[0m"
        self.SEP = f" {self.GRAY}│{self.RESET} "
        self.print_lock = threading.Lock()

    def get_time(self) -> str:
        return datetime.now().strftime("%H:%M:%S")

    def _format_kwarg(self, k: str, v: any) -> str:
        s_val = str(v)
        if k in ['token', 'account']:
            return f"{self.WHITE}token: {self.CYAN}{s_val:<30}{self.RESET}"
        elif k == 'type':
            return f"{self.WHITE}type: {self.GREEN}{s_val:<14}{self.RESET}"
        elif k == 'humanized':
            return f"{self.WHITE}human: {self.VIOLET}{s_val:<15}{self.RESET}"
        elif k == 'age':
            return f"{self.WHITE}age: {self.LIGHT_BLUE}{s_val:<8}{self.RESET}"
        elif k == 'boost':
            return f"{self.WHITE}boost: {self.PINK}{s_val}{self.RESET}"
        elif k == 'nitro':
            return f"{self.WHITE}nitro: {self.PINK}{s_val:<8}{self.RESET}"
        elif k == 'trial':
            return f"{self.WHITE}trial: {self.PINK}{s_val:<13}{self.RESET}"
        elif k == 'discount':
            return f"{self.WHITE}disc: {self.YELLOW}{s_val:<8}{self.RESET}"
        elif k == 'redeemable':
            return f"{self.WHITE}redeem: {self.CYAN}{s_val:<14}{self.RESET}"
        elif k == 'cooldown':
            return f"{self.WHITE}cd: {self.ORANGE}{s_val:<12}{self.RESET}"
        elif k == 'retry_after':
            return f"{self.WHITE}retry: {self.ORANGE}{s_val:<6}{self.RESET}"
        elif k == 'error':
            return f"{self.WHITE}error: {self.RED}{s_val}{self.RESET}"
        else:
            return f"{self.WHITE}{k}: {self.CYAN}{s_val}{self.RESET}"

    def _log(self, color: str, icon: str, tag: str, message: str, **kwargs) -> None:
        with self.print_lock:
            time.sleep(0.003)
            time_str = f"{self.GRAY}[{self.get_time()}]{self.RESET}"
            tag_str = f"{self.GRAY}[{color}{icon} {tag:<4}{self.GRAY}]{self.RESET}"

            # Predictable order for perfect alignment
            key_order = [
                'token', 'type', 'humanized', 'age', 'boost', 'nitro',
                'trial', 'discount', 'redeemable', 'cooldown', 'retry_after', 'error'
            ]
            sorted_keys = [k for k in key_order if k in kwargs] + [k for k in kwargs if k not in key_order]
            formatted_parts = [self._format_kwarg(k, kwargs[k]) for k in sorted_keys]

            if formatted_parts:
                parts_str = self.SEP.join(formatted_parts)
                print(f"{time_str} {tag_str}{self.SEP}{parts_str}", flush=True)
            else:
                msg_str = f"{self.WHITE}{message}{self.RESET}" if message else ""
                print(f"{time_str} {tag_str}{self.SEP}{msg_str}", flush=True)

    def info(self, msg: str, **kwargs) -> None:
        self._log(self.CYAN, "ℹ", "INFO", msg, **kwargs)

    def success(self, msg: str, **kwargs) -> None:
        self._log(self.GREEN, "✓", "OKAY", msg, **kwargs)

    def fail(self, msg: str, **kwargs) -> None:
        self._log(self.RED, "✗", "FAIL", msg, **kwargs)

    def warning(self, msg: str, **kwargs) -> None:
        self._log(self.YELLOW, "⚠", "WARN", msg, **kwargs)

    def error(self, msg: str, **kwargs) -> None:
        self._log(self.RED, "✗", "ERR", msg, **kwargs)


log = Logger()