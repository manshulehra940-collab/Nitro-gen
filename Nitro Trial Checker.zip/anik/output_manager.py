import os
import threading
import time
from typing import Optional, Dict, Any


class OutputManager:
    """
    Thread-safe output manager for Zenkai / AnikChecker V1.
    Organizes results into clean, hierarchical folders and files.
    """

    def __init__(self, base_folder: str) -> None:
        self.base_folder = base_folder
        self.lock = threading.Lock()
        self._created_dirs = set()
        self._ensure_dir(self.base_folder)

    def _ensure_dir(self, directory: str) -> None:
        if directory and directory not in self._created_dirs:
            os.makedirs(directory, exist_ok=True)
            self._created_dirs.add(directory)

    def write(self, rel_path: str, content: str) -> None:
        """Write content line to a relative path inside output folder in a thread-safe way."""
        full_path = os.path.join(self.base_folder, rel_path)
        dir_name = os.path.dirname(full_path)
        with self.lock:
            if dir_name:
                self._ensure_dir(dir_name)
            with open(full_path, 'a', encoding='utf-8') as f:
                f.write(content + '\n')

    def save_valid(self, token: str, type_name: Optional[str] = None) -> None:
        self.write('Valid.txt', token)
        if type_name:
            self.write(f'Types/{type_name}.txt', token)

    def save_invalid(self, token: str) -> None:
        self.write('Invalid.txt', token)

    def save_locked(self, token: str) -> None:
        self.write('Locked.txt', token)

    def save_flagged(self, token: str) -> None:
        self.write('Flagged.txt', token)

    def save_trial(self, token: str, trial_name: str, trial_id: Optional[str] = None) -> None:
        if trial_name == "1 Month Trial":
            self.write('Trials/1 Month Trial.txt', token)
        elif trial_name == "2 Week Trial":
            self.write('Trials/2 Week Trial.txt', token)
        else:
            self.write('Trials/Other Trials.txt', token)
        
        # Save to aggregated trials file
        record = f"{token} | ID: {trial_id}" if trial_id else token
        self.write('Trials/All Trials.txt', record)

    def save_discount(self, token: str) -> None:
        self.write('Trials/Discounts.txt', token)

    def save_nitro(self, token: str, month: str, days_left: float, boosts: int, cooldown: Any) -> None:
        self.write(f'Nitro/Subscriptions/{month}.txt', token)
        self.write(f'Nitro/Boosts/{boosts} Boosts.txt', token)

        if cooldown is None:
            self.write('Nitro/Cooldown/No Cooldown.txt', token)
            self.write(f'Nitro/Detailed/No Cooldown/{month}/{days_left:.0f} days/{boosts} boosts.txt', token)
        else:
            self.write('Nitro/Cooldown/Cooldown.txt', token)
            self.write(f'Nitro/Detailed/Cooldown/{month}/{days_left:.0f} days/{boosts} boosts.txt', token)

    def save_no_nitro(self, token: str) -> None:
        self.write('Nitro/No Nitro.txt', token)

    def save_humanized(self, token: str, stage_label: str) -> None:
        self.write(f'Humanized/{stage_label}.txt', token)

    def save_redeemable(self, token: str, is_redeemable: bool) -> None:
        if is_redeemable:
            self.write('Redeemable/Redeemable.txt', token)
        else:
            self.write('Redeemable/Non Redeemable.txt', token)

    def save_age(self, token: str, age_days: int, type_name: Optional[str] = None) -> None:
        if age_days <= 7:
            range_folder = "0-7 Days"
        elif age_days <= 30:
            range_folder = "8-30 Days"
        elif age_days <= 90:
            range_folder = "31-90 Days"
        elif age_days <= 365:
            range_folder = "91-365 Days"
        else:
            range_folder = "1+ Years"

        self.write(f'Age/Ranges/{range_folder}.txt', token)
        self.write(f'Age/Exact Days/{age_days} Days.txt', token)
        if type_name:
            self.write(f'Age/Exact Days/{age_days} Days/{type_name}.txt', token)

    def save_summary(self, stats: Dict[str, Any], elapsed_str: str) -> None:
        """Write clean, organized run summary report."""
        summary_text = (
            "==================================================\n"
            "             ZENKAI CHECKER - SUMMARY             \n"
            "==================================================\n"
            f" Date / Time      : {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f" Duration         : {elapsed_str}\n"
            f" Total Checked    : {stats.get('current', 0)} / {stats.get('total', 0)}\n"
            "--------------------------------------------------\n"
            f" Valid Tokens     : {stats.get('valid', 0)}\n"
            f" Invalid Tokens   : {stats.get('invalid', 0)}\n"
            f" Locked Tokens    : {stats.get('locked', 0)}\n"
            f" Flagged Tokens   : {stats.get('flagged', 0)}\n"
            "--------------------------------------------------\n"
            f" Active Nitro     : {stats.get('nitro', 0)}\n"
            f" No Nitro         : {stats.get('no_nitro', 0)}\n"
            f" 2-Week Trials    : {stats.get('trials_2w', 0)}\n"
            f" 1-Month Trials   : {stats.get('trials_1m', 0)}\n"
            f" Other Trials     : {stats.get('trials_other', 0)}\n"
            f" Discounts Found  : {stats.get('discounts', 0)}\n"
            "--------------------------------------------------\n"
            f" Redeemable       : {stats.get('redeemable', 0)}\n"
            f" Non-Redeemable   : {stats.get('non_redeemable', 0)}\n"
            "--------------------------------------------------\n"
            f" Humanized S3     : {stats.get('humanized_s3', 0)} (Fully)\n"
            f" Humanized S2     : {stats.get('humanized_s2', 0)} (Half)\n"
            f" Humanized S1     : {stats.get('humanized_s1', 0)} (Nothing)\n"
            "==================================================\n"
        )
        self.write('Summary.txt', summary_text.rstrip())
