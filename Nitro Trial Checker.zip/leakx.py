import sys
import os
import subprocess

REQUIRED_PACKAGES = {
    "colorama": "colorama",
    "pystyle": "pystyle",
    "toml": "toml",
    "curl_cffi": "curl_cffi",
    "requests": "requests",
}

missing_packages = []
for module_name, package_name in REQUIRED_PACKAGES.items():
    try:
        __import__(module_name)
    except ImportError:
        missing_packages.append(package_name)

if missing_packages:
    print(f"Missing required packages: {', '.join(missing_packages)}")
    print("Installing them now...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing_packages])
        print("Successfully installed missing packages.\n")
    except Exception as e:
        print(f"Failed to install packages: {e}")
        print("Please install them manually using: pip install " + " ".join(missing_packages))
        sys.exit(1)

import colorama
import time
import ctypes
import concurrent.futures
import msvcrt
import json
import random
import threading
import pystyle
import toml
from curl_cffi import requests as request
from datetime import datetime
from colorama import init, Fore, Style
from anik import OutputManager, log, Colors

# Override theme colors
Colors.CYAN = Fore.MAGENTA
Colors.GRAY = Fore.YELLOW
Colors.GREEN = Fore.YELLOW

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

init(autoreset=True)

# ==================== ASCII BANNER ====================
BANNER = r'''
          $$$$$$$$\  $$$$$$\  $$\   $$\             $$\   $$\ 
$$        $$  _____|$$  __$$\ $$ | $$  |            $$ |  $$ |
$$        $$ |      $$ /  $$ |$$ |$$  /             \$$\ $$  |
$$        $$$$$\    $$$$$$$$ |$$$$$  /               \$$$$  / 
$$        $$  __|   $$  __$$ |$$  $$<                $$  $$<  
$$        $$ |      $$ |  $$ |$$ |\$$\              $$  /\$$\ 
$$$$$$$$$ $$$$$$$$\ $$ |  $$ |$$ | \$$\             $$ /  $$ |
\________|\________|\__|  \__|\__|  \__|            \__|  \__|
'''

BANNER_ART = r'''
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⡴⠒⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣴⣶⣿⣿⠟⠁⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣶⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣾⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⣛⣻⣤⣤⣶⠶⠚⠋⠉⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⢠⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢛⣋⣭⣴⣶⣿⣿⣿⣿⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⠀⢠⡿⠀⠀⣀⡤⠀⠀⢀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⡿⠟⣋⣥⣴⣾⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⣾⢃⣴⡿⠁⣠⣾⣯⣤⣴⣾⣿⣋⡁⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⠿⢋⣡⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣴⣟⣵⣿⢏⣴⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠷⠦⣄⠀⠀⠀⢻⣿⣿⣿⡿⠋⣡⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣯⣾⣿⢧⣻⣿⡞⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠀⠀⠀⠈⢿⣿⠋⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢀⣴⣿⢿⣿⣿⣿⣿⣝⣺⠟⠋⠉⠈⠉⠻⣿⣿⣿⣿⣿⣿⣿⢿⣆⠀⠀⠀⠘⣯⠀⢉⣉⣭⣭⣭⣭⣭⣙⣛⣛⠻⠿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢻⣿⣤⣾⡿⣿⣿⣿⡿⠷⠖⠂⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⡂⠘⠇⠀⠀⠀⣿⣆⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣭⣟⣻⢿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣴⣠⣴⣿⣿⠿⣿⣧⣿⣿⠟⠛⠓⠀⠀⠀⠀⠀⠀⣸⣽⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⣸⣿⣿⡄⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠛⠛⠛⠚⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢿⣧⣿⡿⠅⣼⠏⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⢀⣚⠿⣷⣿⣿⣿⣿⠻⣿⠀⠀⠀⣰⣿⣿⣿⠇⢸⣿⣿⣿⣿⣿⣿⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠈⠿⠑⠬⠴⣃⣴⣿⠀⠀⠀⠀⠀⠀⠀⢀⠺⣿⡿⣱⣿⣿⣿⣿⠃⠠⠃⠀⢀⣼⣿⣿⣿⠏⢀⣾⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⠙⠛⠋⠉⠀⠀⠀⠀⠀⣴⣿⣿⡗⣼⣿⣿⣿⣿⣿⡀⠀⢀⣴⣿⣿⠿⢛⠅⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣦⣭⣽⢸⣿⣿⣿⣿⣯⠘⠇⠠⢛⣩⣭⣶⢞⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⠟⠛⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⢿⣿⡏⣿⣿⣿⣿⣿⣿⣷⣖⣴⣿⣿⢟⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⣷⣶⣶⣶⡶⠤⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣿⣶⣾⣧⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⠿⢟⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⡿⣿⠿⢟⣛⣛⣻⣿⣿⣿⣿⣿⣿⣿⣶⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣶⠿⣦⡉⣿⠀⠀⠀⠻⣛⣵⣿⣧⢿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⡿⠼⠋⠈⠀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⡴⢻⣿⣿⣿⣿⣷⣄⣀⡀⠀⢙⡻⢿⣎⢻⣿⣿⣿⣿⢹⣿⢻⡿⠃⠋⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡟⠀⠀⠈⣹⡿⠿⢿⣿⣿⣿⣿⣷⡮⠁⠙⢿⣿⣿⡌⠉⠀⠀⠀⠀⠀⠀⢀⠀⠈⠿⣿⣿⣿⣿⣿⡿⠿⣿⠿⢿⣿⣿⣿⣿⣿⣇⠙⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠲⠞⠏⠀⠀⠀⠀⠉⠛⠛⢿⠁⠀⣰⣿⣿⣿⡿⠦⠄⠀⠀⠀⢠⣞⣿⣦⣄⡀⠈⠛⠻⢿⣿⣷⡀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣄⠀⠀⠀⠀⣡⣾⣿⡿⠟⠛⠓⠀⠀⠀⠀⣠⣟⢩⣿⢿⣿⣿⣿⣷⣶⣶⣿⣿⣧⠀⠀⠸⣿⣿⣿⣿⣿⣿⢿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣋⣙⣿⣶⣶⣿⣿⠟⠉⠀⠀⠀⠀⣀⣴⣾⣿⣷⣇⡿⣇⣾⣻⣧⣀⠀⠈⠉⠛⠿⣿⣧⡀⠀⣿⣿⣿⣿⣿⣿⠀⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡟⢩⣽⠿⠛⠛⠛⢻⣄⠀⠀⠀⣠⣾⣿⣿⡿⠟⠛⠉⠁⠉⠚⠾⣿⣿⣧⡀⠀⠀⠀⠀⡿⠁⠀⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠂⠸⣇⠀⠀⠀⠀⣰⠏⠀⠀⣴⣿⣿⡿⠋⠀⠀⠀⠀⣀⡀⠀⠀⠈⢿⣿⣷⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠁⠀⠀⠀⢠⡾⠁⠀⠀⠀⠀⠘⣿⣿⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣟⠀⠀⠀⠀⢿⣇⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠘⢿⣶⣤⣤⣤⣾⣿⠟⠁⠀⠀⠀⣠⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣧⡀⠀⠀⠀⠀⠈⠙⠛⠋⠉⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣦⣄⣀⠀⠀⠀⠀⠀⣀⣠⣤⣾⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⢿⣿⣿⣿⣿⡿⠿⠿⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
'''
# ==========================================================

def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Orange color for main banner
    orange = Fore.LIGHTYELLOW_EX + Fore.LIGHTRED_EX  # Mix for orange effect
    yellow = Fore.YELLOW
    red = Fore.RED
    black = Fore.BLACK
    white = Fore.WHITE
    
    # Print main banner in orange
    for line in BANNER.split('\n'):
        if line.strip():
            print(f"{Fore.LIGHTYELLOW_EX}{line}{Fore.RESET}")
    
    print()
    
    # Print detailed ASCII art with mixed colors
    color_cycle = [Fore.LIGHTYELLOW_EX, Fore.LIGHTRED_EX, Fore.RED, Fore.YELLOW, Fore.LIGHTBLACK_EX]
    art_lines = BANNER_ART.split('\n')
    
    for i, line in enumerate(art_lines):
        if line.strip():
            color_idx = i % len(color_cycle)
            print(f"{color_cycle[color_idx]}{line}{Fore.RESET}")
    
    print()
    
    # Title without emoji
    title = "FrostChecker Tool"
    try:
        columns = os.get_terminal_size().columns
    except Exception:
        columns = 80
    
    padding = max(0, (columns - len(title)) // 2)
    print(f"{' ' * padding}{Fore.LIGHTYELLOW_EX}{title}{Fore.RESET}")
    print()
    
    # Discord link
    discord_line = "Join our Discord: .gg/leakX"
    discord_padding = max(0, (columns - len(discord_line)) // 2)
    print(f"{' ' * discord_padding}{Fore.LIGHTRED_EX}Join our Discord: {Fore.LIGHTYELLOW_EX}.gg/leakX{Fore.RESET}")
    
    # Developer line
    dev_line = "Developer: Tool By Frosty"
    dev_padding = max(0, (columns - len(dev_line)) // 2)
    print(f"{' ' * dev_padding}{Fore.LIGHTRED_EX}Developer: {Fore.LIGHTYELLOW_EX}Tool By Frosty{Fore.RESET}")
    print()

# Ensure data directory and files exist
os.makedirs('data', exist_ok=True)
if not os.path.exists('data/config.toml'):
    with open('data/config.toml', 'w', encoding='utf-8') as f:
        f.write('[main]\nthreads = 100\nproxyless = true\n')

if not os.path.exists('data/settings.json'):
    with open('data/settings.json', 'w', encoding='utf-8') as f:
        f.write('{\n    "nitro": true,\n    "age": true,\n    "type": true,\n    "flagged": true,\n    "redeemable": true,\n    "trial": true,\n    "humanized": true\n}\n')

if not os.path.exists('data/proxies.txt'):
    with open('data/proxies.txt', 'w', encoding='utf-8') as f:
        pass

# Ensure tokens.txt exists
if not os.path.exists('tokens.txt'):
    with open('tokens.txt', 'w', encoding='utf-8') as f:
        pass
    print_banner()
    log.fail("tokens.txt was not found and has been created. Please add your tokens to tokens.txt and restart.")
    input("\nPress Enter to exit...")
    sys.exit(0)

# Ask user if they want to run the tool
print_banner()
print(f"{Fore.LIGHTYELLOW_EX}Do you want to run the tool? (Y/N): {Fore.RESET}", end='')
choice = input().strip().upper()

if choice != 'Y':
    print(f"{Fore.LIGHTRED_EX}Exiting...{Fore.RESET}")
    sys.exit(0)

print(f"{Fore.LIGHTYELLOW_EX}Starting tool...{Fore.RESET}\n")

with open('tokens.txt', 'r', encoding='utf-8') as f:
    tokens = [line.strip() for line in f.readlines() if line.strip() and not line.strip().startswith('#')]

if not tokens:
    print_banner()
    log.fail("No tokens found in tokens.txt! Please add your tokens to tokens.txt and restart.")
    input("\nPress Enter to exit...")
    sys.exit(0)

proxies_path = 'data/proxies.txt' if os.path.exists('data/proxies.txt') else 'anik/data/proxies.txt'
proxies = []
if os.path.exists(proxies_path):
    with open(proxies_path, 'r', encoding='utf-8') as f:
        proxies = [line.strip() for line in f.readlines() if line.strip()]

tokens = list(set(tokens))

valid = 0
invalid = 0
locked = 0
nitro = 0
flagged = 0
total = len(tokens)
current = 0
no_nitro = 0
redeemable = 0
non_redeemable = 0
trials_2w = 0
trials_1m = 0
trials_other = 0
discounts = 0
humanized_s3 = 0
humanized_s2 = 0
humanized_s1 = 0
done = False

config_path = 'data/config.toml' if os.path.exists('data/config.toml') else 'anik/data/config.toml'
settings_path = 'data/settings.json' if os.path.exists('data/settings.json') else 'anik/data/settings.json'

config = toml.load(config_path) if os.path.exists(config_path) else {'main': {'threads': 100, 'proxyless': True}}
settings = json.loads(open(settings_path, 'r', encoding='utf-8').read()) if os.path.exists(settings_path) else {
    "nitro": True, "age": True, "type": True, "flagged": True, "redeemable": True, "trial": True, "humanized": True
}

LOCK = threading.Lock()
TOKEN_LOCK = threading.Lock()
PRINT_LOCK = threading.Lock()
MAX_RETRIES_PER_TOKEN = 3
REQUEST_TIMEOUT = 20

# Print banner again after confirmation
print_banner()

output_folder = f"output/{time.strftime('%Y-%m-%d %H-%M-%S')}"
output_manager = OutputManager(output_folder)
log.info('Loading tokens...', output=output_folder, total=total)
print()

start = time.time()
rate_limit_cooldown = 0
rate_limit_lock = threading.Lock()


class Checker:
    def __init__(self) -> None:
        self.new_session()

    def new_session(self) -> None:
        self.session = request.Session(impersonate='chrome131')
        self.session.headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
            'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"'
        }
        if not config['main'].get('proxyless', True) and proxies:
            try:
                proxy = random.choice(proxies)
                self.session.proxies = {'http': proxy, 'https': proxy}
            except Exception:
                pass

    def retry_errors(self, e):
        err = str(e).lower()
        return (
            'connection' in err or 'timeout' in err or 'reset' in err or
            'refused' in err or 'network' in err or 'curl' in err or
            'ssl' in err or 'certificate' in err or 'remote host' in err or
            'closed' in err or 'abruptly' in err
        )

    def check(self) -> None:
        global flagged, no_nitro, nitro, non_redeemable
        global locked, redeemable, invalid, valid, current, rate_limit_cooldown
        global trials_2w, trials_1m, trials_other, discounts, humanized_s3, humanized_s2, humanized_s1
        while True:
            TOKEN_LOCK.acquire()
            if not tokens:
                TOKEN_LOCK.release()
                break
            token = tokens.pop().strip()
            TOKEN_LOCK.release()

            token_only = token.split(':')[-1]
            half_token = token_only[:20]
            masked_token = half_token + '.***.*****'
            args = {'token': masked_token}

            for attempt in range(MAX_RETRIES_PER_TOKEN):
                try:
                    with rate_limit_lock:
                        if rate_limit_cooldown > time.time():
                            wait = rate_limit_cooldown - time.time()
                            time.sleep(wait)

                    self.session.headers['authorization'] = token_only

                    r = self.session.get('https://discord.com/api/v9/users/@me/guilds', timeout=REQUEST_TIMEOUT)

                    if r.status_code == 429:
                        retry_after = r.json().get('retry_after', 5)
                        log.warning('Rate limited', retry_after=f'{retry_after}s', token=masked_token)
                        with rate_limit_lock:
                            rate_limit_cooldown = time.time() + retry_after
                        time.sleep(retry_after)
                        TOKEN_LOCK.acquire()
                        tokens.append(token)
                        TOKEN_LOCK.release()
                        break

                    current += 1

                    if r.status_code == 401:
                        invalid += 1
                        log.fail('Invalid', token=masked_token)
                        output_manager.save_invalid(token)
                        break

                    if r.status_code == 403:
                        locked += 1
                        log.fail('Locked', token=masked_token)
                        output_manager.save_locked(token)
                        break

                    if r.status_code != 200:
                        raise Exception(f'Unexpected status {r.status_code}')

                    # Parse guilds count for humanized check before overwriting r
                    guilds_count = 0
                    try:
                        g_json = r.json()
                        guilds_count = len(g_json) if isinstance(g_json, list) else 0
                    except Exception:
                        pass

                    r = self.session.get('https://discord.com/api/v9/users/@me', timeout=REQUEST_TIMEOUT)
                    if r.status_code != 200:
                        raise Exception('users @me failed')

                    try:
                        user_data = r.json()
                    except Exception:
                        user_data = {}

                    if not isinstance(user_data, dict):
                        user_data = {}

                    if settings['flagged'] and (user_data.get('flags') or 0) & 1048576 == 1048576:
                        flagged += 1
                        log.fail('Flagged', **args)
                        output_manager.save_flagged(token)
                        break

                    if settings['type']:
                        type_name = 'Unclaimed'
                        if user_data.get('email') and user_data.get('verified'):
                            type_name = 'Email verified'
                        if user_data.get('phone'):
                            type_name = 'Fully verified' if type_name == 'Email verified' else 'Phone verified'
                    else:
                        type_name = 'Valid'

                    args['type'] = type_name

                    # Humanized check
                    if settings.get('humanized', True):
                        avatar = user_data.get('avatar') is not None
                        bio = bool(str(user_data.get('bio') or '').strip())
                        
                        pronouns = False
                        user_id = user_data.get('id')
                        if user_id:
                            try:
                                r_profile = self.session.get(f'https://discord.com/api/v9/users/{user_id}/profile', timeout=REQUEST_TIMEOUT)
                                if r_profile.status_code == 200:
                                    prof_data = r_profile.json()
                                    user_profile = prof_data.get('user_profile') or {}
                                    pronouns = bool(str(user_profile.get('pronouns') or '').strip())
                            except Exception:
                                pass
                        
                        flags = user_data.get('flags', 0) or user_data.get('public_flags', 0) or 0
                        hypesquad = bool(flags & (4 | 64 | 128 | 256))
                        
                        has_any = avatar or bio or pronouns or hypesquad
                        
                        if avatar and bio and pronouns and hypesquad:
                            humanized_s3 += 1
                            args['humanized'] = 'Stage 3 (Fully)'
                        elif not has_any:
                            humanized_s1 += 1
                            args['humanized'] = 'Stage 1 (Nothing)'
                        else:
                            humanized_s2 += 1
                            args['humanized'] = 'Stage 2 (Half)'
                            
                        output_manager.save_humanized(token, args['humanized'])

                    if settings['age']:
                        try:
                            uid = int(user_data.get('id') or 0)
                            created_at = ((uid >> 22) + 1420070400000) / 1000
                            age_days = int((time.time() - created_at) / 86400)
                            args['age'] = f'{age_days} days'
                            output_manager.save_age(token, age_days, type_name)
                        except Exception:
                            pass

                    if settings['nitro']:
                        try:
                            r2 = self.session.get('https://discord.com/api/v9/users/@me/billing/subscriptions', timeout=REQUEST_TIMEOUT)
                            data = r2.json() if r2.status_code == 200 else []

                            if isinstance(data, list) and data:
                                for sub in data:
                                    if not isinstance(sub, dict):
                                        continue
                                    end = sub.get('current_period_end')
                                    if not end:
                                        continue

                                    days_left = (
                                        time.mktime(time.strptime(end.replace('Z', '+00:00')[:26], '%Y-%m-%dT%H:%M:%S.%f'))
                                        - time.time()
                                    ) / 86400

                                    r3 = self.session.get('https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots', timeout=REQUEST_TIMEOUT)
                                    slots = r3.json() if r3.status_code == 200 else []
                                    available = sum(
                                        1 for s in (slots if isinstance(slots, list) else [])
                                        if isinstance(s, dict) and s.get('cooldown_ends_at') is None
                                    )

                                    month = '1 Month' if days_left <= 31 else '3 Month'
                                    compact_month = '1M' if days_left <= 31 else '3M'

                                    args['boost'] = available
                                    args['nitro'] = f'{compact_month} [{days_left:.0f}d]'
                                    nitro += 1

                                    cooldown = sub.get('cooldown_ends_at')
                                    if cooldown is None:
                                        args['cooldown'] = 'No Cooldown'
                                    else:
                                        dt_obj = datetime.fromisoformat(str(cooldown).replace('Z', '+00:00'))
                                        args['cooldown'] = f'{dt_obj.day}d {dt_obj.hour}hrs'

                                    output_manager.save_nitro(token, month, days_left, available, cooldown)
                            else:
                                args['boost'] = 0
                                args['nitro'] = 'No Nitro'
                                output_manager.save_no_nitro(token)
                                no_nitro += 1
                        except Exception:
                            args['boost'] = 0
                            args['nitro'] = 'No Nitro'
                            output_manager.save_no_nitro(token)
                            no_nitro += 1

                    if settings.get('trial', True):
                        try:
                            headers_trial = {
                                'accept': '*/*',
                                'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                                'authorization': token_only,
                                'content-type': 'application/json',
                                'origin': 'https://discord.com',
                                'priority': 'u=1, i',
                                'referer': 'https://discord.com/channels/@me',
                                'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
                                'sec-ch-ua-mobile': '?0',
                                'sec-ch-ua-platform': '"Windows"',
                                'sec-fetch-dest': 'empty',
                                'sec-fetch-mode': 'cors',
                                'sec-fetch-site': 'same-origin',
                                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
                                'x-debug-options': 'bugReporterEnabled',
                                'x-discord-locale': 'en-US',
                                'x-discord-timezone': 'Asia/Calcutta',
                                'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLUdCIiwiaGFzX2NsaWVudF9tb2RzIjpmYWxzZSwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzOC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTM4LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjQxNzI2NiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbCwiY2xpZW50X2xhdW5jaF9pZCI6Ijg4ZDM3ZTA5LWNhNTEtNDNlYi05NDRmLTcwMmI5OGNmNDNiOSIsImNsaWVudF9hcHBfc3RhdGUiOiJ1bmZvY3VzZWQifQ==',
                            }
                            
                            r_trial = self.session.post('https://discord.com/api/v9/users/@me/billing/user-offer', headers=headers_trial, json={}, timeout=REQUEST_TIMEOUT)
                            if r_trial.status_code == 200:
                                try:
                                    t_data = r_trial.json()
                                    user_trial_offer = t_data.get('user_trial_offer')
                                    if isinstance(user_trial_offer, dict) and user_trial_offer.get('trial_id'):
                                        trial_id = str(user_trial_offer['trial_id'])
                                        sub_trial = user_trial_offer.get('subscription_trial') or {}
                                        interval_count = sub_trial.get('interval_count')
                                        interval = sub_trial.get('interval')
                                        
                                        if trial_id.startswith('5') or interval_count == 30 or (interval == 2 and interval_count == 1):
                                            trial_name = "1 Month Trial"
                                            trials_1m += 1
                                        elif trial_id.startswith('9') or interval_count == 14:
                                            trial_name = "2 Week Trial"
                                            trials_2w += 1
                                        else:
                                            trial_name = f"Trial ({trial_id[:6]})"
                                            trials_other += 1
                                        
                                        args['trial'] = trial_name
                                        output_manager.save_trial(token, trial_name, trial_id)
                                except Exception:
                                    pass

                            r_disc = self.session.post(
                                'https://discord.com/api/v9/users/@me/billing/subscriptions/preview',
                                headers=headers_trial,
                                json={
                                    "items": [{"quantity": 1, "plan_id": "511651880837840896"}],
                                    "payment_source_id": None,
                                    "apply_entitlements": False,
                                    "currency": "usd",
                                    "renewal": True
                                },
                                timeout=REQUEST_TIMEOUT
                            )
                            if r_disc.status_code == 200:
                                try:
                                    d_data = r_disc.json()
                                    discount_found = False
                                    for item in d_data.get('invoice_items', []):
                                        if isinstance(item, dict) and item.get('discounts'):
                                            discount_found = True
                                            break
                                    if discount_found:
                                        discounts += 1
                                        args['discount'] = '40% Off'
                                        output_manager.save_discount(token)
                                except Exception:
                                    pass
                        except Exception:
                            pass

                    if settings['redeemable']:
                        try:
                            r2 = self.session.get('https://discord.com/api/v9/users/@me/billing/subscriptions?include_inactive=true', timeout=REQUEST_TIMEOUT)
                            if r2.status_code == 200 and isinstance(r2.text, str):
                                is_redeemable = '[]' in r2.text
                                if 'trial' not in args:
                                    args['redeemable'] = 'Redeemable' if is_redeemable else 'Non Redeemable'
                                output_manager.save_redeemable(token, is_redeemable)
                                if is_redeemable:
                                    redeemable += 1
                                else:
                                    non_redeemable += 1
                        except Exception:
                            pass

                    valid += 1
                    log.success('Valid', **args)
                    output_manager.save_valid(token, type_name)
                    break

                except Exception as e:
                    if TOKEN_LOCK.locked():
                        try:
                            TOKEN_LOCK.release()
                        except Exception:
                            pass

                    if not self.retry_errors(e) or attempt >= MAX_RETRIES_PER_TOKEN - 1:
                        TOKEN_LOCK.acquire()
                        tokens.append(token)
                        TOKEN_LOCK.release()
                        log.fail('Error', **args, error=str(e)[:50])

                    self.new_session()
                    time.sleep(0.5 + random.uniform(0, 0.5))


def update_title():
    while not done:
        try:
            time.sleep(0.5)  
            if total > 0:  
                elapsed = max(time.time() - start, 0.001)
                pct = current / total * 100
                cps = current / elapsed if elapsed else 0
                ctypes.windll.kernel32.SetConsoleTitleW(
                    f'FrostChecker - Token Checker | Valid: {valid} | Invalid: {invalid} | '
                    f'Locked: {locked} | 2w: {trials_2w} | 1m: {trials_1m} | Disc: {discounts} | '
                    f'Remaining: {len(tokens)} | Checked: {pct:.2f}% | CPS: {cps:.2f}'
                )
        except Exception:
            pass


def wait_for_enter():
    print()  
    while True:
        if msvcrt.kbhit():
            key = msvcrt.getch()
            if key == b'\r':
                break
        time.sleep(0.1)  
    log.info('Exiting...')
    time.sleep(1)


if __name__ == '__main__':
    time.sleep(0.1)
    update = threading.Thread(target=update_title, daemon=True)
    update.start()
    
    threads = config['main']['threads']
    log.info(f'Starting with {threads} threads...')
    print()  
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        futures = []
        for i in range(threads):
            checker = Checker()
            future = executor.submit(checker.check)
            futures.append(future)
        
        for future in concurrent.futures.as_completed(futures):
            pass
    
    done = True
    update.join(timeout=1)
    print()  
    elapsed = time.time() - start
    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)
    log.info(f'Checked {current} tokens in {minutes}m {seconds}s')
    
    stats_dict = {
        'current': current,
        'total': total,
        'valid': valid,
        'invalid': invalid,
        'locked': locked,
        'flagged': flagged,
        'nitro': nitro,
        'no_nitro': no_nitro,
        'trials_2w': trials_2w,
        'trials_1m': trials_1m,
        'trials_other': trials_other,
        'discounts': discounts,
        'redeemable': redeemable,
        'non_redeemable': non_redeemable,
        'humanized_s3': humanized_s3,
        'humanized_s2': humanized_s2,
        'humanized_s1': humanized_s1
    }
    output_manager.save_summary(stats_dict, f"{minutes}m {seconds}s")
    
    # Summary box without emojis
    title = "FINAL SUMMARY"
    col_w1, col_w2, col_w3, col_w4 = 16, 16, 16, 20
    internal_width = col_w1 + col_w2 + col_w3 + col_w4 + 3
    
    print(f"\n{Colors.CYAN}╭{'─' * internal_width}╮{Colors.RESET}")
    
    title_padding = internal_width - len(title)
    left_padding = title_padding // 2
    right_padding = title_padding - left_padding
    print(f"{Colors.CYAN}│{Colors.WHITE}{' ' * left_padding}{title}{' ' * right_padding}{Colors.CYAN}│{Colors.RESET}")
    
    print(f"{Colors.CYAN}├{'─' * col_w1}┬{'─' * col_w2}┬{'─' * col_w3}┬{'─' * col_w4}┤{Colors.RESET}")
    
    p1 = f" Checked: {current}"
    p2 = f" Valid: {valid}"
    p3 = f" Invalid: {invalid}"
    p4 = f" Nitro: {nitro}"
    col1 = f" {Colors.GRAY}Checked: {Colors.CYAN}{current}{Colors.RESET}{' ' * (col_w1 - len(p1))}"
    col2 = f" {Colors.GRAY}Valid: {Colors.GREEN}{valid}{Colors.RESET}{' ' * (col_w2 - len(p2))}"
    col3 = f" {Colors.GRAY}Invalid: {Colors.RED}{invalid}{Colors.RESET}{' ' * (col_w3 - len(p3))}"
    col4 = f" {Colors.GRAY}Nitro: {Colors.PINK}{nitro}{Colors.RESET}{' ' * (col_w4 - len(p4))}"
    row1 = f"{Colors.CYAN}│{Colors.RESET}{col1}{Colors.CYAN}│{Colors.RESET}{col2}{Colors.CYAN}│{Colors.RESET}{col3}{Colors.CYAN}│{Colors.RESET}{col4}{Colors.CYAN}│{Colors.RESET}"
    print(row1)
    
    print(f"{Colors.CYAN}├{'─' * col_w1}┼{'─' * col_w2}┼{'─' * col_w3}┼{'─' * col_w4}┤{Colors.RESET}")
    
    p1 = f" Locked: {locked}"
    p2 = f" Flagged: {flagged}"
    p3 = f" Redeem: {redeemable}"
    p4 = f" Non-Redeem: {non_redeemable}"
    col1 = f" {Colors.GRAY}Locked: {Colors.RED}{locked}{Colors.RESET}{' ' * (col_w1 - len(p1))}"
    col2 = f" {Colors.GRAY}Flagged: {Colors.ORANGE}{flagged}{Colors.RESET}{' ' * (col_w2 - len(p2))}"
    col3 = f" {Colors.GRAY}Redeem: {Colors.CYAN}{redeemable}{Colors.RESET}{' ' * (col_w3 - len(p3))}"
    col4 = f" {Colors.GRAY}Non-Redeem: {Colors.VIOLET}{non_redeemable}{Colors.RESET}{' ' * (col_w4 - len(p4))}"
    row2 = f"{Colors.CYAN}│{Colors.RESET}{col1}{Colors.CYAN}│{Colors.RESET}{col2}{Colors.CYAN}│{Colors.RESET}{col3}{Colors.CYAN}│{Colors.RESET}{col4}{Colors.CYAN}│{Colors.RESET}"
    print(row2)
    
    print(f"{Colors.CYAN}├{'─' * col_w1}┼{'─' * col_w2}┼{'─' * col_w3}┼{'─' * col_w4}┤{Colors.RESET}")
    
    p1 = f" 2w Trial: {trials_2w}"
    p2 = f" 1m Trial: {trials_1m}"
    p3 = f" Discount: {discounts}"
    p4 = f" No Nitro: {no_nitro}"
    col1 = f" {Colors.GRAY}2w Trial: {Colors.CYAN}{trials_2w}{Colors.RESET}{' ' * (col_w1 - len(p1))}"
    col2 = f" {Colors.GRAY}1m Trial: {Colors.PINK}{trials_1m}{Colors.RESET}{' ' * (col_w2 - len(p2))}"
    col3 = f" {Colors.GRAY}Discount: {Colors.YELLOW}{discounts}{Colors.RESET}{' ' * (col_w3 - len(p3))}"
    col4 = f" {Colors.GRAY}No Nitro: {Colors.RED}{no_nitro}{Colors.RESET}{' ' * (col_w4 - len(p4))}"
    row3 = f"{Colors.CYAN}│{Colors.RESET}{col1}{Colors.CYAN}│{Colors.RESET}{col2}{Colors.CYAN}│{Colors.RESET}{col3}{Colors.CYAN}│{Colors.RESET}{col4}{Colors.CYAN}│{Colors.RESET}"
    print(row3)
    
    print(f"{Colors.CYAN}├{'─' * col_w1}┼{'─' * col_w2}┼{'─' * col_w3}┼{'─' * col_w4}┤{Colors.RESET}")
    
    p1 = f" Stage 3: {humanized_s3}"
    p2 = f" Stage 2: {humanized_s2}"
    p3 = f" Stage 1: {humanized_s1}"
    p4 = ""
    col1 = f" {Colors.GRAY}Stage 3: {Colors.GREEN}{humanized_s3}{Colors.RESET}{' ' * (col_w1 - len(p1))}"
    col2 = f" {Colors.GRAY}Stage 2: {Colors.YELLOW}{humanized_s2}{Colors.RESET}{' ' * (col_w2 - len(p2))}"
    col3 = f" {Colors.GRAY}Stage 1: {Colors.RED}{humanized_s1}{Colors.RESET}{' ' * (col_w3 - len(p3))}"
    col4 = f"{Colors.RESET}{' ' * col_w4}"
    row4 = f"{Colors.CYAN}│{Colors.RESET}{col1}{Colors.CYAN}│{Colors.RESET}{col2}{Colors.CYAN}│{Colors.RESET}{col3}{Colors.CYAN}│{Colors.RESET}{col4}{Colors.CYAN}│{Colors.RESET}"
    print(row4)
    
    print(f"{Colors.CYAN}╰{'─' * col_w1}┴{'─' * col_w2}┴{'─' * col_w3}┴{'─' * col_w4}╯{Colors.RESET}")
    
    # Footer without emojis
    print(f"\n  {Colors.GRAY}>> {Colors.WHITE}Thanks for using {Colors.CYAN}FrostChecker{Colors.RESET} {Colors.GRAY}| Developed with {Colors.PINK}love{Colors.GRAY} by {Colors.WHITE}Tool By Frosty{Colors.RESET}")
    print(f"  {Colors.GRAY}Join our Discord: {Colors.CYAN}.gg/leakX{Colors.RESET}\n")
    
    log.info('Press Enter to exit.')
    wait_for_enter()